from setuptools import setup

setup(
  name='blob-metrics',    # This is the name of your PyPI-package.
  version='0.3',                          # Update the version number for new releases
  scripts=['BlobMetrics']                  # The name of your scipt, and also the command you'll be using for calling it
)
